-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 14-Out-2018 às 02:26
-- Versão do servidor: 5.7.19
-- versão do PHP: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `academiadocafe`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cafes`
--

CREATE TABLE `cafes` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` longtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `cafes`
--

INSERT INTO `cafes` (`id`, `nome`, `descricao`) VALUES
(1, 'Café Espresso', 'O café espresso (ou expresso, dependendo da preferência de escrita) é um dos principais tipos de café – e é a base de diversos outros. O nome “espresso” vem do italiano “espremido, pressionado”. Ele é feito em poucos segundos sob alta pressão de água na temperatura de consumo. Isso faz com que acumule muito sabor e intensidade'),
(2, 'Café Macchiato', 'O macchiato é muito parecido com o café espresso, mas adiciona uma dose de leite vaporizado para suavizar o sabor intenso do espresso. Ao redor do mundo, os baristas costumam fazer pequenas variações no macchiato, embora sempre sigam os procedimento básicos da receita original.\n\n        A receita original consiste em uma dose de espresso coberta com uma dose de leite vaporizado (ou em espuma) sobre o café. A receita clássica conta, ainda, com leite vaporizado e espuma de leite, em diferentes camadas.\n\n        A proporção original utiliza um terço de café, um terço de leite vaporizado e um terço de espuma (medidos de acordo com seu volume aparente).'),
(3, 'Café Ristretto', 'O ristretto é uma versão mais concentrada do café espresso padrão. Entre os tipos de café mais populares, é o que apresenta maior intensidade. Basicamente, trata-se da extração da mesma quantidade de café de um espresso, mas em apenas metade da quantidade de água.\n\n            Para ser feito, basta utilizar metade da água na realização de um espresso, ou simplesmente interromper a máquina na metade do processo. Isso garante um sabor concentrado e bastante forte.'),
(4, 'Café Latte', 'O Café Latte não é exatamente uma forma sofisticada de se tratar do café com leite. Em sua receita original, utiliza-se leite vaporizado misturado a uma dose de café espresso, além de 1 centímetro de espuma de leite servido sobre a bebida.\n\nDiferencia-se de um Machiatto especialmente no que diz respeito à proporção e à forma como é servido. No Machiatto, as três camadas são servidas sem estarem misturadas dentro da xícara. Já no Latte, o café e o leite vaporizado são misturados, com a espuma servida sobre a mistura, separadamente.'),
(5, 'Cappuccino', 'O Cappuccino é bastante parecido com um Latte, e é um dos tipos de café mais populares em cafeterias e bares ao redor do mundo. A diferença entre os dois está no fato de o cappuccino possuir mais leite vaporizado em sua fórmula, além de chocolate adicionado à receita.\n\nSua receita inclui uma dose de café espresso misturado com leite vaporizado, espuma de leite e chocolate em pequenos pedaços ou em pó sobre a bebida.\n\nDiferencia-se de um Machiatto especialmente no que diz respeito à proporção e à forma como é servido. No Machiatto, as três camadas são servidas sem estarem misturadas dentro da xícara. Já no Latte, o café e o leite vaporizado são misturados, com a espuma servida sobre a mistura, separadamente.'),
(6, 'Mocha', 'O Mocha é uma versão ainda mais achocolatada do Cappuccino. Na prática, é uma mistura entre um Cappuccino e chocolate quente. É feito a partir da mistura do chocolate em pó com uma dose de espresso, adicionando leite vaporizado e espuma de leite – todos homogeneamente misturados dentro da bebida.\n\nPara completar na apresentação, costuma-se polvilhar chocolate em pó ou em pequenos pedaços sobre a bebida'),
(7, 'Affogato', 'O affogato é mais uma sobremesa do que um drink, o que o torna especialmente delicioso, Consiste na mistura de uma boa colherada de sorvete de baunilha com uma ou duas doses de café espresso. Muitas pessoas discutem sua presença entre os tipos de café, dizendo que deveria ser considerado um doce.\n\nNo entanto, uma receita tão deliciosa simplesmente não poderia ficar de fora da lista. Além disso, há uma versão ainda mais animada da bebida que inclui uma dose de licor de amêndoas na mistura.');

-- --------------------------------------------------------

--
-- Estrutura da tabela `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(7, '2018_10_11_215933_cria_tabela_cafes', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cafes`
--
ALTER TABLE `cafes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cafes`
--
ALTER TABLE `cafes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
